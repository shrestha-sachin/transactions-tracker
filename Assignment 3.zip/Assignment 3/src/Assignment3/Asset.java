package Assignment3;

public abstract class Asset {
    public abstract double getMarketValue();
    public abstract String toString();
    public abstract String getName();
}
