package Assignment3;

public class main {

	public static void main(String[] args) {
		
		
			Portfolio Port = new Portfolio(); 
			Port.ProcessCommands (); 
			System.out.println("\nProgram will terminate!"); 
			}
		

	}


